import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { TaskService } from '../task.service';
import * as alertify from 'alertifyjs';


@Component({
  selector: 'app-highpriority',
  templateUrl: './highpriority.component.html',
  styleUrls: ['./highpriority.component.css']
})
export class HighpriorityComponent implements OnInit {

  display = "none";

  constructor(private router:Router,private taskservice:TaskService,private snackBar:MatSnackBar ) {}
  email:any
  taskList:any
  username:string
  initialValues:any

  addtaskForm=new FormGroup({
    taskId:new FormControl("",Validators.required),
    taskTitle:new FormControl(""),
    description:new FormControl(""),
    date:new FormControl("",Validators.required),
    priority:new FormControl("",Validators.required)
  })

  get taskId(){
    return this.addtaskForm.get('taskId');
  }
  get taskTitle(){
    return this.addtaskForm.get('taskTitle');
  }
  get description(){
    return this.addtaskForm.get('description');
  }
  get date(){
    return this.addtaskForm.get('date');
  }
  get priority(){
    return this.addtaskForm.get('priority');
  }


  ngOnInit():void{
    this.initialValues=this.addtaskForm.value;
    this.getTasks();
    this.username=localStorage.getItem("username");
  }

  getTasks(){
    this.email=localStorage.getItem("emailId");
    this.taskservice.highprioritytask(this.email)
    .subscribe(response=>{
      this.taskList=response;
      this.taskList.sort(function(a:any,b:any){
        if(a.priority=='Low')
        {
          return 0;
        }
        else if(a.priority>b.priority){
          return 1;
        }
        return -1;

      })
      let currentDate=new Date();
      this.incomplete=this.taskList.filter((a:any)=>{
        let a_date=new Date(a.date);
        return a_date<=currentDate;
      })
      this.noOfIncomplete=this.incomplete.length;

    })
  }

  deleteTask(taskId:any):void{
    this.taskservice.deleteTask(taskId)
    .subscribe(response=>{
      alertify.success(response);
      this.getTasks();
    }); 
  }

  toedit(task:any){
    localStorage.setItem("TaskId",task.taskId);
    localStorage.setItem("TaskTitle",task.taskTitle);
    localStorage.setItem("TaskDescription",task.description);
    localStorage.setItem("TaskDate",task.date);
    localStorage.setItem("TaskPriority",task.priority);
    localStorage.setItem("TaskImage",task.image);
    this.router.navigateByUrl('/uploadstudio');
  }


  openModal(){
    this.display="block";
  }

  onCloseHandled(){
    this.display="none";
  }

  openSnackBar(message:string,action:any,taskId:string){
    let snackBarRef=this.snackBar.open(message,action);

    snackBarRef.afterDismissed().subscribe(()=>{
      console.log('After completion'+taskId);
      this.deleteTask(taskId);
      this.getTasks();
    })
  }


  isBadgeHidden:boolean=true
  noOfIncomplete:number=0;
  incomplete:any


}
