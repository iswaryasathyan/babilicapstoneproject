import { Component } from '@angular/core';
import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { Observable } from 'rxjs';
import { map, shareReplay } from 'rxjs/operators';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { TaskService } from '../task.service';

@Component({
  selector: 'app-studio',
  templateUrl: './studio.component.html',
  styleUrls: ['./studio.component.css']
})
export class StudioComponent {
  display = "none";

  isHandset$: Observable<boolean> = this.breakpointObserver.observe(Breakpoints.Handset)
    .pipe(
      map(result => result.matches),
      shareReplay()
    );

  constructor(private breakpointObserver: BreakpointObserver,private taskservice:TaskService) {}
  noOfIncomplete:number=0;
  openModal(){
    this.display="block";

  }
  isBadgeHidden:boolean=true;


  userlist:any
  email:any

  registerForm=new FormGroup({
    username:new FormControl('',[Validators.required, Validators.minLength(4)]),
  })
  
  get username(){
    return this.registerForm.get('username');
  }

  getUserDetails():void{
    this.email=localStorage.getItem("emailId")
    this.taskservice.getUserDetails(this.email).subscribe(response=>{
      console.log(response);
      this.userlist=response;
    })

  }

}
